# iCWLNet-Distributed-PHP-Website-Builder
 Bubble CMS Website Bulder, front end Content Management from central administration http://sitemanage.info
 Local PHP application retrieves current website content from remote server using a similar code to load balancing.
 Template and Content static files are kept in remote central domain:- https://assets.creativeweblogic.net
 Local php app handles session and cookie data perfectly, also form fields and URI address variables. Also file uploads. 
